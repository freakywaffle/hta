package nio_file;

import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ResourceBundle;

import com.sun.javafx.image.PixelSetter;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class FileConnectController implements Initializable {
	@FXML Button con_bt;
	@FXML TextField ip_tf;
	
	SocketChannel socket;
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
		
		con_bt.setOnAction(ee->{
			try {
				String ip = ip_tf.getText();
				
				socket = SocketChannel.open();
				socket.configureBlocking(true);
				
				socket.connect(new InetSocketAddress(ip, 7777));
				System.out.println("���� ���� ����");
				
				
				Path pp = Paths.get("Test/neogul.jpg");
				
				
				FileChannel channel = FileChannel.open(pp, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
				
//				Charset charset = Charset.defaultCharset();
				
				int cnt = 0;
				int cap = 1024;
				
				while(cnt > -1) {
						ByteBuffer buf = ByteBuffer.allocate(cap);
						cnt = socket.read(buf);
						if(cnt != -1) {							
							buf.flip();
							channel.write(buf);
							buf.clear();
							if(cnt < cap) {
								break;
							}
						}
				}		
				channel.close();
				socket.close();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}

}
