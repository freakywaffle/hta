package nio_file;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import com.sun.javafx.image.IntPixelSetter;


class FileSender extends Thread{

	SocketChannel socket;
	
	public FileSender(SocketChannel socket) {
		super();
		this.socket = socket;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			FileChannel channel = FileChannel.open(Paths.get("ppp/neogul.jpg"), StandardOpenOption.READ);
			ByteBuffer buf = ByteBuffer.allocate(1024);
//			Charset charset = Charset.defaultCharset();
			int cnt = 0;
			while(true) {
				cnt = channel.read(buf);
				
				if(cnt==-1)  
					break;
				buf.flip();
//				socket.write(charset.encode(charset.decode(buf)));
				socket.write(buf);
				buf.clear();
			}
			
			channel.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}

public class TransFileServer{

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ServerSocketChannel server = ServerSocketChannel.open();
			server.configureBlocking(true);
			server.bind(new InetSocketAddress(7777));
			
			while(true) {
				System.out.println("�������");	
				
				SocketChannel client = server.accept();
				System.out.println("Ŭ���̾�Ʈ ����");
				
				new FileSender(client).start();				
				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
